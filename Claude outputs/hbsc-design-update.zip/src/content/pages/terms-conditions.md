---
title: "Terms and Conditions"
description: "The terms governing use of the Homebuyers SC website."
kind: main
oldUrl: "/terms-conditions/"
---
**SMS Terms & Conditions**

**Last Updated - October 1, 2025**

**Terms of Use**

By accessing and using this website, web page, client portal, or mobile application, including but not limited to any content, functionality and services offered on or through this website, web page, client portal, or mobile application, or our e-mails, texts, posts and other electronic messages (collectively, our “Site”), you are agreeing to be bound by these Terms and Conditions of Use, all applicable laws and regulations, and agree that you are responsible for compliance with any applicable local laws. If you do not agree with any of these terms, you are prohibited from using or accessing this Site.

Our Site and all of the contents, features and functionality (including but not limited to all information, software, text, displays, images, video and audio, and the design, selection and arrangement thereof), are owned by us, our licensors or other providers of such material and are protected by United States and international copyright, trademark, patent, trade secret and other intellectual property or proprietary rights laws, as applicable. We reserve the right to withdraw or amend our Site, and any service or material we provide on our Site, in our sole discretion without notice. We will not be liable if, for any reason, all or any part of our Site is unavailable at any time or for any period.

### Use License
Your permission to use and access this Site is the grant of a limited license, not a transfer of title, and your limited license to use or access our Site shall automatically terminate if you violate any of these restrictions and may be terminated by us at any time for any reason or no reason.

* When using or accessing our Site, you may not:modify or copy any material or Services; use the material or Services for any commercial purpose, or for any public display (commercial or non-commercial);attempt to decompile or reverse engineer any software contained on the Site or that supports the Site or any Services; engage in any data mining, data harvesting, data extracting or any other similar activity in relation to this Site, or while using this Site; remove any copyright or other proprietary notations from the material; or transfer the materials to another person or entity or “mirror” the material on any other server.
* Posting Content. In these Terms and Conditions of Use, your “Content” shall mean any audio, video, text, images or other material, including comments or feedback, you choose to post on or submit to us via this Website. With respect to your Content, by posting it in a way that is visible to the public, you grant us a non-exclusive, worldwide, irrevocable, royalty-free, sub-licensable license to use, reproduce, adapt, publish, translate and distribute it on our Site and in any and all media. Your Content must be your own and must not be infringing on any third party’s rights or violate any of the restrictions in the subsection below. We reserve the right to remove any of your Content from our Site at any time, and for any reason, without notice.
* Without limiting the foregoing, you agree not to use, or permit to be used, any messaging capabilities or any Services on our Site that permit text entry or the uploading or posting of audio, video or images to post, transmit or disseminate any:unsolicited material to persons or entities that have not agreed to receive such material or to whom you do not otherwise have a legal right to send such material; material that infringes or violates any third party’s intellectual property rights, rights of publicity, privacy, or confidentiality, or the rights or legal obligations of any wireless service provider or any of its customers or subscribers attempt to decompile or reverse engineer any software contained on the Site or that supports the Site or any Services; material or data that is illegal, or material or data that is harassing, coercive, libelous, defamatory, abusive, threatening, obscene, or otherwise objectionable, materials that are harmful to minors or excessive in quantity, or materials the transmission of which could diminish or harm the reputation of us and/or our third- party service providers; material or data that is related to illegal drugs (e.g., marijuana, cocaine) or to pharmaceuticals, material that contains any viruses, Trojan horses, worms, time bombs, cancelbots, or other computer programming routines that are intended to damage, detrimentally interfere with, surreptitiously intercept or expropriate any system, data, or personal information or contains any signal or impulse that could cause electrical, magnetic, optical, or other technical harm to our equipment or facilities and/or those of any third party; or material or information that is false or misleading, or likely to mislead or deceive.
* Your permission to use and access this Site is the grant of a limited license, not a transfer of title, and your limited license to use or access our Site shall automatically terminate if you violate any of these restrictions and may be terminated by us at any time for any reason or no reason.  

### Disclaimer
You understand that we cannot and do not guarantee or warrant that files available for downloading from the internet or our Site will be free of viruses or other destructive code. You are responsible for implementing sufficient procedures and checkpoints to satisfy your particular requirements for anti-virus protection and accuracy of data input and output, and for maintaining a means external to our site for any reconstruction of any lost data. WE WILL NOT BE LIABLE FOR ANY LOSS OR DAMAGE CAUSED BY A DISTRIBUTED DENIAL-OF-SERVICE ATTACK, VIRUSES OR OTHER TECHNOLOGICALLY HARMFUL MATERIAL THAT MAY INFECT YOUR COMPUTER EQUIPMENT, COMPUTER PROGRAMS, DATA OR OTHER PROPRIETARY MATERIAL DUE TO YOUR USE OF OUR SITE OR ANY SERVICES OR ITEMS OBTAINED THROUGH OUR SITE OR TO YOUR DOWNLOADING OF ANY MATERIAL POSTED ON IT, OR ON ANY WEBSITE LINKED TO OR FROM IT. THE MATERIALS ON THE SITE ARE PROVIDED ON AN “AS IS” AND “AS AVAILABLE” BASIS. WE MAKES NO WARRANTIES, EXPRESSED OR IMPLIED, AND HEREBY DISCLAIMS AND NEGATES ALL OTHER WARRANTIES, INCLUDING WITHOUT LIMITATION, IMPLIED WARRANTIES OR CONDITIONS OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, OR NON-INFRINGEMENT OF INTELLECTUAL PROPERTY OR OTHER VIOLATION OF RIGHTS. FURTHER, WE DO NOT WARRANT OR MAKE ANY REPRESENTATIONS CONCERNING THE ACCURACY, LIKELY RESULTS, OR RELIABILITY OF THE USE OF THE MATERIALS ON SITE OR OTHERWISE RELATING TO SUCH MATERIALS OR ON ANY SITE LINKED TO THE SITE.

### **  
Limitation of Liability**

IN NO EVENT WILL WE, OUR AFFILIATES OR OUR OR THEIR LICENSORS, SERVICE PROVIDERS, AGENTS, EMPLOYEES, OFFICERS OR DIRECTORS BE LIABLE FOR DAMAGES OF ANY KIND, UNDER ANY LEGAL THEORY, ARISING OUT OF OR IN CONNECTION WITH YOUR USE, OR INABILITY TO USE, OUR SITE, ANY WEBSITES LINKED TO OR FROM IT, ANY CONTENT ON OUR SITE OR ON SUCH OTHER WEBSITES, OR ANY SERVICES OR ITEMS OBTAINED THROUGH OUR SITE OR SUCH OTHER WEBSITES, INCLUDING ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL, CONSEQUENTIAL OR PUNITIVE DAMAGES, INCLUDING BUT NOT LIMITED TO, PERSONAL INJURY, PAIN AND SUFFERING, EMOTIONAL DISTRESS, LOSS OF REVENUE, LOSS OF PROFITS, LOSS OF BUSINESS OR ANTICIPATED SAVINGS, LOSS OF USE, LOSS OF GOODWILL, LOSS OF DATA, AND WHETHER CAUSED BY TORT (INCLUDING NEGLIGENCE), BREACH OF CONTRACT OR OTHERWISE, EVEN IF FORESEEABLE. THE FOREGOING DOES NOT AFFECT ANY LIABILITY WHICH CANNOT BE EXCLUDED OR LIMITED UNDER APPLICABLE LAW.  

### Indemnification
You agree to defend, indemnify and hold harmless us, our affiliates, licensors and service providers, and our and their respective officers, directors, employees, contractors, agents, licensors, suppliers, successors and assigns from and against any claims, liabilities, damages, judgments, awards, losses, costs, expenses or fees (including reasonable attorneys’ fees) arising out of or relating to your violation of these Terms and Conditions of Use and your use of our Site, including, but not limited to, any use of our Site’s content, services and products other than as expressly authorized in these Terms and Conditions of Use or your use of any information obtained from our Site.

### **  
Revisions and Errata**

The materials appearing on our Site could include technical, typographical, or photographic errors. We do not warrant that any of the materials on the Site are accurate, complete, or current. We may make changes to the materials contained on the Site at any time without notice. We do not, however, make any commitment to update the materials.

### **  
Links**

We have not reviewed all of the third-party websites linked to by the Site and are not responsible for the contents of any such linked site. The inclusion of any link does not imply endorsement by us of the third-party website. Navigation to and use of any such linked website is at the user’s own risk.

### **  
Site Terms of Use Modifications**

We may revise these Terms and Conditions of Use for the Site at any time without notice. By accessing or using the Site, you are agreeing to be bound by the then current version of these Terms and Conditions of Use.

### **  
Governing Law**

Any claim relating to the Site shall be governed by the laws of the State in which we are headquartered without regard to its conflict of law provisions.

### **  
Entire Agreement**

These Terms and Conditions of Use, our Privacy Policy and any other document we deem relevant constitute the sole and entire agreement between you and us with respect to our Site and supersede all prior and contemporaneous understandings, agreements, representations and warranties, both written and oral, with respect to our Site.  

**Privacy Policy**

This Privacy Policy explains how Homebuyers SC collects, uses and discloses personal information of its customers, prospective customers, and visitors to its website at homebuyerssc.com.  

COLLECTION OF PERSONAL INFORMATION

Information collected directly from you: We may collect personal information directly from you, for

example through a web form. Personal information we collect directly from you may include first and last name, address, email address, and phone number.

Information collected from your device: Our website may use tracking technologies such as cookies, web

beacons, pixels, and other similar technologies to automatically collect certain information from your

device, including for example your IP address, browser and operating system information, geographic

location, referring website address, and other information about how you interact with the website.

Our email campaigns may also use tracking technologies such as web beacons, pixels and other similar technologies to automatically collect certain information such as your IP address, browser type and version, and email engagement statistics.

Information collected from our advertising partners: We may collect personal information about you

from our advertising partners. Personal information we collect from our advertising partners may

include your demographic information, shopping history, and geographic location.  

USE OF PERSONAL INFORMATION

We use information collected directly from you to provide you with our products and services, customer

service and support, and other relevant information. We may also use this information to market our

products and services to you, including by email and text message subject to your consent.

We use information collected from our advertising partners to market our products and services to

you.  

DISCLOSURE OF PERSONAL INFORMATION

We may use third-party service providers to assist us with providing and marketing our products and

services to you and we may share your information with such third parties for these limited purposes.

● We use RESimpli for our email marketing and text message communications. For more

information about how we may use your information with RESimpli and the information

that may be collected through our email campaigns, see RESimpli’s Customer Data

Notice available at https://resimpli.com/privacy-policy/

● We use LeadPages to help us understand how visitors interact with our website. LeadPages uses and processes your information in accordance with its privacy policy available at https://www.leadpages.com/privacy?srsltid=AfmBOor9Fmcze4f_T_PDLDgslDe2O8GpiYcqXj8iiu-H_CiboDfCW7pI.

We may also share your personal information if necessary to comply with applicable laws and regulations, to respond to a subpoena, search warrant or other lawful request for information we receive, or to otherwise protect our rights.

  
EMAIL AND TEXT MESSAGE COMMUNICATIONS

If you wish to unsubscribe from our email campaigns, please click on the Unsubscribe link at the bottom

of any marketing email sent from us.

If you wish to stop receiving text messages from us, reply STOP , QUIT , CANCEL, OPT-OUT , or

UNSUBSCRIBE to any text message sent from us. For more information, see our Mobile Messaging Terms

and Conditions available at [insert link to your mobile terms].

CHANGES TO THE THIS PRIVACY POLICY

We may update this Privacy Policy at any time. Please review it frequently.

CONTACT INFORMATION

If you have any questions about this policy or our privacy practices, please contact us at homebuyerssc@gmail.com.
